import requests
import bs4
from bs4 import BeautifulSoup


# 该函数是用来爬取指定合同列表页面的所有合同数据
def get(i):
    # 先根据指定的索引，拼接出完整的网页地址
    url = "http://htgs.ccgp.gov.cn/GS8/contractpublish/index_"+str(i)

    # requests库用于获取指定网页的html源码
    res = requests.get(url)

    # 创建一个BeautifulSoup解析对象，将html源码解析成便于处理的BeautifulSoup结构
    soup = BeautifulSoup(res.content, "html.parser", from_encoding="utf-8")

    # 由于列表网页中的所有核心合同数据都在ul标签中，并且该标签的class为“ulst”
    # 因此只用截取该标签中内容即可
    ul = soup.find('ul', class_="ulst")

    # 这里的root是用于和合同详情页的相对地址拼接出完整的地址，具体见for中的使用
    root = "http://htgs.ccgp.gov.cn/GS8/contractpublish"

    # 遍历ul中的li，获取每一个合同
    for li in ul:
        # 这个if只是做简单的判断，略过不是合同的那些li
        if isinstance(li, bs4.element.Tag):
            # 执行到这里的li都是符合我们要求的li，即是我们想要处理的合同
            # 遍历li中的a标签，a标签即是超链接标签，目的是为了获取合同的详情页网址
            for a in li.find_all('a', attrs={'style': "display:inline;"}):
                # 打不打印都无所谓，这里的print意义不大
                print(a.string.strip(), a.get("href"))
                # 将获取到的详情页网址和上面的基地址root拼接出完整的地址，存入txt文本中
                # 注意：
                # 1. strip函数用于去掉字符串的首部和尾部多余的空格
                # 2. "\t"是制表符，用于空格，把合同的名称及其地址分隔开
                # 3. "\n"是为了换行，每个合同占用txt文本中的一行
                fo.write(a.string.strip() + "\t" + root + a.get("href")[1:-1] + "\n")
            print("------------------------------------------")


# >>>>> 这里是代码执行的入口
# >>>>> 这个脚本文件的作用是：获取30个合同列表页面的一共600条合同（每页20条）的详情页地址
# >>>>> 并且将这600条内容存入txt文本中保存

# 先打开文件，爬取得内容将会写进这个文件，这个文件的文件和该程序脚本同目录下
fo = open("foo.txt", "w", encoding="utf-8")
index = 0
# 循环30次，按索引爬取30个页面
while index < 30:
    # 调用列表页爬虫函数，入参是索引，该函数的定义在上面
    get(index+1)
    index += 1

fo.close()
