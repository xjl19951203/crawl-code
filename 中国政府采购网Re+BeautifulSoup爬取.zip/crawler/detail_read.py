import requests
from bs4 import BeautifulSoup
import json

# dataList是一个数组，或者说是列表，存放600份合同的详情数据
# dataList中的每一个元素是字典类型，即{}，{}中以键值对，即合同的每个属性都是一个键值对
global dataList
dataList = []


# 该函数根据传入的table，解析合同的所有属性
def analysis(table, url):
    # 需要申明全局表量，才能在函数中使用该变量
    global dataList

    # 接下来的这三个表量不用太关注，主要用于进一步解析链接地址
    CONTACT_URL = "合同附件（链接）："
    ANNOUNCEMENT = "中标、成交公告："
    ANNOUNCEMENT_URL = "中标、成交公告（链接）："

    # 每个合同是一个字典类型，里面有多个键值对，每个键值对是合同的一项属性
    dic = {}
    # 遍历table的tr，tr就是表格的一行，合同有多少属性，就会有多少个tr
    for tr in table.findAll('tr'):
        # tr是表格的一行，每行有很多列，列即是td
        # key是行的第一列，即是键值对的“键”，使用strip去掉字符串前后的空格
        key = tr.findAll('td')[0].getText().strip()
        # 键对应的“值”就是行的第二列
        dic[key] = tr.findAll('td')[-1].getText().strip()
        # 这个if判断，主要用于进一步获取合同的附件链接，不用关注
        if key == ANNOUNCEMENT:
            dic[ANNOUNCEMENT_URL] = tr.findAll('td')[-1].find_all('a')[0].get("href")
    # 这条语句主要存放该合同页面的地址
    dic[CONTACT_URL] = url
    print(dic)
    # 一条合同到此为止所有的属性都装进字典dic中，然后将dic作为一个合同添加至合同数组dataList中
    dataList.append(dic)


# 该函数的作用是获取指定合同网址的合同详情数据
def get(url):
    # 根据网址获取HTML源码
    res = requests.get(url)
    # 创建一个BeautifulSoup解析对象，解析源码
    soup = BeautifulSoup(res.content, "html.parser", from_encoding="utf-8")
    # 根据table标签和id找到合同详情的那个表格内容
    table = soup.find('table', id="queryTable")
    # 调用analysis方法，将table中的所有合同属性进行解析
    analysis(table, url)


# >>>>> 这里是代码执行的入口
# >>>>> 这个脚本的作用是：根据上一份脚本得到的600条详情页链接，循环爬取这600个合同的详情数据，存放到json文本中
# 先打开上个脚本获取的600份合同详情页的txt文本
fo = open("foo.txt", "r", encoding="utf-8")

# 读取一行数据，即一份合同
line = fo.readline()             # 调用文件的 readline()方法
while line:
    # 将一行字符串按制表符“\t”分隔成数组，并获取数组最后一个元素，即详情页的网址
    # line.split("\t")[-1]这条语句即获取合同的网址，作为参数传入get方法中
    get(line.split("\t")[-1])
    # 接着读取下一行，开启写一条合同的爬取
    line = fo.readline()
# 关闭txt文件
fo.close()

# 将所有合同形成的json数据dataList写成Json文件
with open("list.json", "w", encoding='utf8') as f:
    json.dump(dataList, f, ensure_ascii=False,)
    print("加载入文件完成...")

