# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html

import pymysql

class GovermentPipeline(object):
    def process_item(self, item, spider):
        return item

class GovermentInfoPipeline(object):
    def process_item(self, item, spider):
        # 连接数据库
        my_sql = pymysql.connect(host='localhost', port=3306, user='root', password='mysql951203', charset='utf8',
                                 db='goverment', use_unicode=True)
        # 获取游标
        cur = my_sql.cursor()
        try:
            sql = "insert into goverment_zd (合同编号, 合同名称, 项目编号, 项目名称, 采购人, 供应商, 所属地域, 所属行业, 合同金额, 合同签订日期, 合同公告日期, 代理机构, 中标成交公告, 合同附件, 免责声明) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            params = (item["合同编号："], item["合同名称："], item["项目编号："], item["项目名称："], item["采购人(甲方)："], item["供应商(乙方)："], item["所属地域："], item["所属行业："], item["合同金额："], item["合同签订日期："], item["合同公告日期："], item["代理机构："], item["中标、成交公告（链接）："], item["合同附件："], item["免责声明"])
            cur.execute(sql, params)
            # 提交
            my_sql.commit()
            # 关闭游标
            cur.close()
            # 关闭数据库连接
            my_sql.close()
        except Exception as e:
            my_sql.commit()
            cur.close()
            my_sql.close()
            print("出现异常：", e)
        finally:
            return item
