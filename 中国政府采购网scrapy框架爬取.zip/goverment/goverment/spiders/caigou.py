# -*- coding: utf-8 -*-
import scrapy
import re

class CaigouSpider(scrapy.Spider):
    name = 'caigou'
    start_urls = ['http://htgs.ccgp.gov.cn/GS8/contractpublish/search']#初始URL，用来获取下一步的页面的URL
    base_url = 'http://htgs.ccgp.gov.cn/GS8/contractpublish/index_'   #用以构造其他页面的URL

#定义一个实现生成页面request请求的函数
    def parse(self, response):
        #提取当前URL页面中包含的所有合同的URL
        for href in response.css('a::attr(href)').extract():  #对于每一个a标签，将其中的href属性中的内容提取出来
            try:     #try-except判断实现异常处理
                xmbm = re.findall(r"\w{32}", href)[0]   #提取href中的代表每个页面的特征的URL中的核心不同点
                url = 'http://htgs.ccgp.gov.cn/GS8/contractpublish/detail/'+xmbm+'?contractSign=0'    #将提取的特征码与其他公共部分组合成相应的页面URL
                yield scrapy.Request(url, callback=self.parse_xm)   #利用生成器开始不断生成URL进行抓取
            except:
                continue
        # 上一个页面的合同信息爬取完后利用for循环将下一个的页面URL提取出来，作为一个新的request请求发送给engine进而给到schueler重新进行爬取
        for next_url in range(2, 30):
            yield scrapy.Request(url=self.base_url +str(next_url), callback=self.parse)



#定义一个对页面内容进行处理的函数
    def parse_xm(self, response):
        infoDict = {}  #定义一个空字典用来存放合同表中的键值对
        xmInfo = response.css(".vT_detail_main")    #提取vT_detail_main中的所有内容
        htmc = xmInfo.css("h2::text").extract()[0]      #提取xmInfo中所有的h2标签中的第一h2标签的文本内容
        keyList = xmInfo.css("label").extract()   #提取xmInfo中所有的label标签中的文本内容（合同表中的第一列内容）
        valueList = xmInfo.css("td::text").extract()    #提取xmInfo中所有的td标签中的文本内容（按理说，这里应该包括了合同表第一列和第二列的所有内容，但是不知道为什么只有第二列的内容，甚至有\r\n\t在里面）
        zhenzhilist = valueList[2::3]   #提取valueList中的value即第二列中有用的内容，将没用的\t\n\r去掉
        # 将所有的keyList和zhenzhilist中的值赋值给infoDict[],作为输出
        for i in range(len(keyList)):
            key = re.findall(r">.*</label>", keyList[i])[0][1:-8]     #利用正则表达式将keyList放在<label>标签中的文本内容提取出来
            if key == "合同金额：":
                try:     #使用try-except避免金额的值为空
                    middlevalue = re.findall(r"\d*\.\d{6}万元", zhenzhilist[i])[0]    #利用正则表达式将合同金额单独提取出来，并在下一个语句中去掉空白（\t\r\n）
                    value = middlevalue.strip()
                except:
                    value = '--'
            elif key == "免责声明":   #同上合同金额
                middlevalue = valueList[-1]
                value = middlevalue.strip()
            elif key == "中标、成交公告：":   #因为合同表中中标、成交公告是以链接的形式给出的，因此进行相应的转换并显示
                key = "中标、成交公告（链接）："
                value = xmInfo.css("a::attr(href)").extract()[0]
            elif key == "合同附件：":
                value == xmInfo.css("b::text").extract()     #同上中标、成交公告
            else:
                try:
                    middlevalue = re.findall(r"\r\n\t\t\t\t\t\t\t.*\r\n\t\t\t\t\t\t", zhenzhilist[i])[0]
                    value = middlevalue.strip()
                except:
                    value = "--"
            infoDict[key] = value

        print("------------------------------------------------------------")

        yield infoDict
